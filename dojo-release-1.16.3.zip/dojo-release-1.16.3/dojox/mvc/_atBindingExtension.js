//>>built
define("dojox/mvc/_atBindingExtension",["dojo/_base/config","dojo/has","dijit/_WidgetBase","./atBindingExtension"],function(_1,_2,_3,_4){
_2.add("mvc-extension-per-widget",(_1["mvc"]||{}).extensionPerWidget);
if(!_2("mvc-extension-per-widget")){
_4(_3.prototype);
}
});
