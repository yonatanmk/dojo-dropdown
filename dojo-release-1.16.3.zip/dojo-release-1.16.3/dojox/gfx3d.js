//>>built
define("dojox/gfx3d",["dojo/_base/kernel","dojox","./gfx3d/matrix","./gfx3d/_base","./gfx3d/object"],function(_1,_2){
_1.getObject("gfx3d",true,_2);
return _2.gfx3d;
});
