define("dojox/image", ["./image/_base"], function(image){
	/*=====
	 return {
	 // summary:
	 //		Deprecated.  Should require dojox/image modules directly rather than trying to access them through
	 //		this module.
	 };
	 =====*/
	return image;
});