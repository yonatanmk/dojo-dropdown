//>>built
define("dojox/validate",["./validate/_base"],function(_1){
return _1;
});
