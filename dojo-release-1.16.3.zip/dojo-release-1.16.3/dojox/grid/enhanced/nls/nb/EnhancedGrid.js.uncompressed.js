define(
"dojox/grid/enhanced/nls/nb/EnhancedGrid", ({
	singleSort: "Enkel sortering",
	nestedSort: "Nestet sortering",
	ascending: "Klikk for å sortere stigende",
	descending: "Klikk for å sortere synkende",
	sortingState: "${0} - ${1}",
	unsorted: "Ikke sorter denne kolonnen",
	indirectSelectionRadio: "Rad ${0}, enkeltvalg, valgknapp",
	indirectSelectionCheckBox: "Rad ${0}, flervalg, avmerkingsboks",
	selectAll: "Velg alle"
})
);
