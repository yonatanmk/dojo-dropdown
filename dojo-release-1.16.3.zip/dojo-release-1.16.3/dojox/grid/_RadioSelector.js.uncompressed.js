define("dojox/grid/_RadioSelector", ["../main", "./_Selector"], function(dojox){
	return dojox.grid._RadioSelector;
});