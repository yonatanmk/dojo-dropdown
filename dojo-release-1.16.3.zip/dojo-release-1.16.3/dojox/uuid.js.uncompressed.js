define("dojox/uuid", ['dojox/uuid/_base'], function(uuid){

	/*=====
	 return {
	 // summary:
	 //		Deprecated.  Should require dojox/uuid modules directly rather than trying to access them through
	 //		this module.
	 };
	 =====*/
	return uuid;
});
