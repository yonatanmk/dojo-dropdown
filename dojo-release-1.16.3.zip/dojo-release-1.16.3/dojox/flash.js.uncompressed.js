define("dojox/flash", ['./flash/_base'],function(){
	/*=====
	 return {
	 // summary:
	 //		Deprecated.  Should require dojox/flash modules directly rather than trying to access them through
	 //		this module.
	 };
	 =====*/
});
